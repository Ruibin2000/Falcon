import sys
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/nyu/Desktop/Falcon_repo/Falcon/scripts/flexric')
from test_kpm_app_subscription import Suite
from argparse import Namespace
import json
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/falcon-kpm-subscription-rrq7ig7y/base5/demonstration')
suite=Suite(Namespace(broker='/home/nyu/flexric/build-kpm-broker/examples/xApp/c/monitor/xapp_kpm_broker',dummy='/home/nyu/Desktop/Falcon_repo/Falcon/scripts/flexric/dummy_kpm_client.py',fixture_plugin='/usr/local/lib/flexric/libkpm_sm.so',output_dir=str(root)))
suite.command('fixture-generator',['/home/nyu/flexric/build-kpm-broker/examples/xApp/c/monitor/falcon_kpm_broker_fixture',str(suite.fixtures)])
suite.dummy_pair(period=1000,reports=30)
suite.equality()
(root/'summary.json').write_text(json.dumps({'status':'passed','source':'fixture','fixture_period_ms':1000,'independent_clients':2,'minimum_rows_per_client':30,'live_acceptance':'pending'},indent=2))
print(root/'summary.json')
