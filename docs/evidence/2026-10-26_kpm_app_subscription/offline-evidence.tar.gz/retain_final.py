from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
repo=Path('/home/nyu/Desktop/Falcon_repo/Falcon');flex=Path('/home/nyu/flexric');work=Path('/tmp/falcon-kpm-subscription-rrq7ig7y');dest=repo/'docs/evidence/2026-10-26_kpm_app_subscription'
normal=work/'base5/tests-deadlines';san=work/'base5/sanitizers-deadlines';demo=work/'base5/demonstration-deadlines'
for name,root in [('normal',normal),('sanitizer',san/'tests'),('demonstration',demo)]:
 result=json.loads((root/'summary.json').read_text());assert result['status']=='passed'
 if name!='demonstration':assert result['required']==25 and result['passed']==25 and result['skipped']==0
 shutil.copyfile(root/'summary.json',dest/f'{name}-summary.json');shutil.copyfile(root/'equality.json',dest/f'{name}-equality.json')
assert json.loads((normal/'equality.json').read_text())['rows_compared']==128
assert json.loads((san/'tests/equality.json').read_text())['rows_compared']==128
assert json.loads((demo/'equality.json').read_text())['rows_compared']==62
manifest=json.loads((dest/'manifest.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in manifest['original_artifacts_unchanged'].items())
manifest['source_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in manifest['source_sha256']}
manifest['binary_and_plugin_sha256']=json.loads((normal/'sha256.json').read_text())
(work/'source-sha256.json').write_text(json.dumps(manifest['source_sha256'],indent=2))
command=json.loads((work/'base5/normal-suite.command.json').read_text());command['argv'][-1]=str(normal)
(work/'base5/normal-suite.command.json').write_text(json.dumps(command,indent=2))
sanitizer_driver=json.loads((work/'base5/sanitizers-final/driver.command.json').read_text());sanitizer_driver['argv'][-1]=str(san)
(san/'driver.command.json').write_text(json.dumps(sanitizer_driver,indent=2))
(demo/'driver.command.json').write_text(json.dumps({'argv':['python3',str(work/'base5/demonstrate.py'),str(demo)],'exit_code':0},indent=2))
shutil.copyfile('/tmp/falcon-kpm-build.log',work/'baseline/build.log');shutil.copyfile(flex/'build-kpm-broker/CMakeCache.txt',work/'baseline/CMakeCache.txt')
(work/'baseline/final-configure.command.json').write_text(json.dumps({'argv':['cmake','-S',str(flex),'-B',str(flex/'build-kpm-broker'),'-DFALCON_KPM_BROKER=ON',f'-DFALCON_REPO_ROOT={repo}'],'env':{'PKG_CONFIG_PATH':'/tmp/falcon-kpm-deps/pkgconfig'},'exit_code':0},indent=2))
archive=dest/'offline-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for root in [work/'baseline',normal,san,demo]:
  for p in sorted(root.rglob('*')):
   if p.is_file() and p.name not in ('broker','unit-test'):tar.add(p,arcname=str(p.relative_to(work)),recursive=False)
 for sub in ['base5/demonstrate.py','base5/normal-suite.command.json','source-sha256.json','retain_final.py']:
  tar.add(work/sub,arcname=sub,recursive=False)
 tar.add(repo/'patches/flexric/kpm-app-subscription-base5.patch',arcname='kpm-app-subscription-base5.patch',recursive=False)
manifest['archive']={'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
manifest['final_evidence']={'normal':str(normal),'sanitizers':str(san),'demonstration':str(demo)}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 entries=tar.getnames();assert len(entries)==len(set(entries));assert all(not p.startswith('/') and '..' not in Path(p).parts for p in entries)
 print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_files':len(entries),'all_checks':'passed'},indent=2))
